import {
  Truck,
  Wrench,
  Users,
  Building,
  Utensils,
  CalendarDays,
  Package,
  ShieldCheck,
  Clock,
  CheckCircle2,
  Phone,
  Mail,
  MapPin,
  ArrowRight,
  ChevronDown,
  Quote,
  TrendingUp,
  Target,
  Lightbulb,
  Trophy
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useState } from 'react';

const FADE_UP = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } }
};

const STAGGER = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function App() {
  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans selection:bg-accent selection:text-white">
      <Navbar />
      <main>
        <HeroSection />
        <CeoSection />
        <AboutAndMissionSection />
        <AchievementsSection />
        <InteractiveServices />
        <WhyChooseUs />
        <ClientsSection />
        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}

function Navbar() {
  return (
    <nav className="fixed top-0 inset-x-0 bg-white/80 backdrop-blur-md z-50 border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        <div className="flex items-center">
          <img src="/logo.png" alt="Sawaed Company Logo" className="h-14 md:h-16 w-auto object-contain" />
        </div>
        <div className="hidden md:flex items-center gap-8 text-sm font-medium">
          <a href="#services" className="hover:text-accent transition-colors">Services</a>
          <a href="#about" className="hover:text-accent transition-colors">About</a>
          <a href="#contact" className="hover:text-accent transition-colors">Contact</a>
          <a href="#contact" className="bg-industrial-900 text-white px-5 py-2.5 rounded-none hover:bg-accent transition-colors">Get a Quote</a>
        </div>
      </div>
    </nav>
  );
}

function HeroSection() {
  return (
    <section className="relative h-screen min-h-[600px] flex items-center justify-center overflow-hidden bg-industrial-900 mt-20 md:mt-0 pt-20 md:pt-0">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=2670&auto=format&fit=crop"
          alt="Industrial Operations and Logistics" 
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/60 mix-blend-multiply"></div>
      </div>

      <div className="relative z-10 w-full max-w-5xl mx-auto px-4 text-center">
        <motion.div initial="hidden" animate="visible" variants={STAGGER}>
          <motion.h1 
            variants={FADE_UP}
            className="font-display text-5xl md:text-7xl font-bold text-white leading-[1.1] tracking-tight mb-6"
          >
            Complete Industrial <br className="hidden md:block"/> Support Solutions
          </motion.h1>
          <motion.p 
            variants={FADE_UP}
            className="text-lg md:text-xl text-gray-200 mb-10 max-w-2xl mx-auto font-light"
          >
            Transport, equipment, manpower, and rental services built for large scale projects
          </motion.p>
          <motion.div variants={FADE_UP} className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <a href="#contact" className="w-full sm:w-auto px-8 py-4 bg-accent text-industrial-900 font-bold text-sm tracking-wide uppercase hover:bg-white transition-colors duration-300">
              Get a Quote
            </a>
            <a href="#services" className="w-full sm:w-auto px-8 py-4 bg-transparent border border-white text-white font-bold text-sm tracking-wide uppercase hover:bg-white hover:text-industrial-900 transition-colors duration-300">
              Explore Services
            </a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}

function CeoSection() {
  return (
    <section className="py-24 bg-industrial-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto bg-white p-8 md:p-12 shadow-sm flex flex-col md:flex-row gap-8 md:gap-16 items-center">
          <div className="w-full md:w-1/3 flex flex-col items-center text-center">
            <div className="w-48 h-48 rounded-full overflow-hidden mb-6 border-4 border-industrial-100 shadow-inner">
              <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=1000&auto=format&fit=crop" alt="Irfan Khan - CEO" className="w-full h-full object-cover" />
            </div>
            <h3 className="font-display font-bold text-2xl text-industrial-900">Irfan Khan</h3>
            <p className="text-accent font-semibold tracking-wider text-sm uppercase mt-1">CEO</p>
          </div>
          <div className="w-full md:w-2/3 relative">
            <Quote className="absolute -top-8 -left-6 w-16 h-16 text-industrial-100 rotate-180 -z-0" />
            <h2 className="font-display text-3xl font-bold tracking-tight text-industrial-900 mb-6 relative z-10">CEO Statement</h2>
            <div className="space-y-4 text-gray-600 font-light leading-relaxed relative z-10">
              <p>As the Chief Executive Officer, I am deeply committed to leading our company with integrity, innovation, and a clear vision for sustainable growth. Our mission is to deliver exceptional value through reliable services in transport, equipment, manpower, catering, event organizing, warehousing, and real estate rentals.</p>
              <p>We believe that success is built on trust, teamwork, and a relentless pursuit of excellence. Every project we undertake reflects our dedication to quality, efficiency, and customer satisfaction.</p>
              <p className="font-medium text-industrial-900 italic mt-6 border-l-4 border-accent pl-4">"Together, we are not just building a business — we are shaping a legacy of reliability, service, and progress for our clients and communities."</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function AboutAndMissionSection() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={FADE_UP}>
            <h2 className="font-display text-4xl font-bold tracking-tight text-industrial-900 mb-6">About Company</h2>
            <div className="w-16 h-1 bg-accent mb-8"></div>
            <div className="space-y-4 text-gray-600 font-light mb-12">
              <p>Our organization is a multifaceted service provider delivering comprehensive solutions across various sectors, including transportation, equipment supply, manpower services, catering, event management, warehousing, and real estate rentals. With an unwavering commitment to quality, reliability, and customer satisfaction, we have established ourselves as a trusted partner for both businesses and individuals.</p>
              <p>We take pride in offering end-to-end solutions tailored to the unique requirements of each client. Our integrated approach encompasses logistics, manpower support, event management, and property rentals, ensuring efficiency, professionalism, and excellence in every endeavor.</p>
              <p>Fueled by innovation and supported by strong leadership, our company is continuously expanding its reach and capabilities. We are dedicated to creating long-term value through sustainable practices, strategic partnerships, and a committed team that shares our vision for growth and success.</p>
              <p>Our mission is clear: to provide reliable services that empower our clients, strengthen communities, and contribute to economic development.</p>
            </div>

            <div className="space-y-8">
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-industrial-100 flex items-center justify-center text-accent rounded"><Target className="w-5 h-5"/></div>
                  <h3 className="font-display text-2xl font-bold text-industrial-900">Our Mission</h3>
                </div>
                <p className="text-gray-600 font-light pl-13 leading-relaxed">To provide high-quality, reliable, and efficient rental and support services that empower the construction and industrial sectors of Saudi Arabia. We are committed to delivering comprehensive solutions in transportation, equipment, manpower, catering, event management, warehousing, and real estate rentals, ensuring that every project is executed with the utmost safety, precision, and excellence. Our mission is to cultivate long-term partnerships founded on trust, innovation, and exceptional service, contributing to the success of our clients and the achievement of Vision 2030.</p>
              </div>
              <div>
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-industrial-100 flex items-center justify-center text-accent rounded"><Lightbulb className="w-5 h-5"/></div>
                  <h3 className="font-display text-2xl font-bold text-industrial-900">Our Vision</h3>
                </div>
                <p className="text-gray-600 font-light pl-13 leading-relaxed">To establish ourselves as a premier multi-service company recognized for our commitment to excellence, innovation, and reliability across diverse sectors, including transportation, equipment supply, manpower services, catering, event management, warehousing, and real estate rentals. We are dedicated to setting new benchmarks in service quality and operational efficiency while promoting sustainable growth that benefits our clients, employees, and the communities we serve. Our vision is to create enduring value through integrity, collaboration, and a steadfast commitment to continuous improvement, positioning our organization as a trusted partner in every industry we engage with.</p>
              </div>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1, transition: { duration: 0.6 } }} 
            viewport={{ once: true }}
            className="aspect-square lg:aspect-auto lg:h-[700px] bg-gray-200 relative overflow-hidden group rounded-sm"
          >
            <img 
              src="https://images.unsplash.com/photo-1504307651254-35680f356f90?q=80&w=2662&auto=format&fit=crop"
              alt="Industrial and Commercial Development"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            {/* Overlay to ensure Logo pops */}
            <div className="absolute inset-0 bg-industrial-900/30"></div>
            
            {/* Logo placement area (mixed with picture) */}
            <div className="absolute inset-0 flex items-center justify-center p-6">
              <div className="bg-white/95 backdrop-blur-md p-10 border-b-4 border-accent shadow-2xl max-w-sm w-full text-center flex flex-col items-center justify-center">
                 {/* 
                    USER: You can replace this inner content with your actual <img src="/logo.png" /> 
                  */}
                 <img src="/logo.png" alt="Sawaed Company Logo" className="w-48 h-auto object-contain mb-4" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

const ACHIEVEMENTS = [
  "Successfully broadened our operational footprint across diverse sectors, including transport, equipment rental, manpower services, catering, event management, warehousing, and real estate.",
  "Cultivated a robust reputation for reliability, safety, and high-quality service within Saudi Arabia's construction and industrial sectors.",
  "Collaborated with prominent national and international firms to facilitate significant infrastructure and development initiatives aligned with Vision 2030.",
  "Attained consistent year-on-year growth through meticulous strategic planning, operational excellence, and a steadfast commitment to customer satisfaction.",
  "Developed a skilled and diverse workforce dedicated to delivering excellence and fostering innovation in every project.",
  "Established advanced safety and quality management systems to ensure adherence to industry standards.",
  "Enhanced our asset portfolio with state-of-the-art equipment and facilities to address increasing market demands.",
  "Acknowledged for our contributions to sustainable development and for supporting the Kingdom's economic diversification objectives."
];

function AchievementsSection() {
  return (
    <section className="py-24 bg-industrial-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 z-0 opacity-20">
        <img src="https://images.unsplash.com/photo-1574719602441-15f18bf5d70f?q=80&w=2670&auto=format&fit=crop" alt="Achievements Background" className="w-full h-full object-cover grayscale" />
        <div className="absolute inset-0 bg-industrial-900/80 mix-blend-multiply"></div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl font-bold tracking-tight mb-4">Business Achievements</h2>
          <div className="w-16 h-1 bg-accent mx-auto"></div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6 max-w-4xl mx-auto">
          {ACHIEVEMENTS.map((achieve, idx) => (
            <motion.div 
              initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: idx * 0.1 }}
              key={idx} className="flex items-start gap-4 bg-white/5 p-6 border border-white/10 hover:bg-white/10 transition-colors"
            >
              <Trophy className="w-6 h-6 text-accent flex-shrink-0 mt-1" />
              <p className="text-gray-300 leading-relaxed text-sm md:text-base">{achieve}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

const WHY_POINTS = [
  { text: "Proven industry experience", icon: ShieldCheck },
  { text: "Fast project response", icon: Clock },
  { text: "Complete service coverage", icon: Package },
  { text: "Strong safety standards", icon: CheckCircle2 },
  { text: "24/7 operational support", icon: Phone },
];

function WhyChooseUs() {
  return (
    <section className="py-20 bg-industrial-900 text-white border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row gap-12 justify-between items-start md:items-center">
          <div className="w-full md:w-1/3">
            <h2 className="font-display text-3xl font-bold tracking-tight">Why Companies<br/>Choose Us</h2>
            <div className="w-16 h-1 bg-accent mt-6"></div>
          </div>
          
          <div className="w-full md:w-2/3">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-8 gap-x-12">
              {WHY_POINTS.map((pt, idx) => (
                <div key={idx} className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center flex-shrink-0 text-accent">
                    <pt.icon className="w-5 h-5" />
                  </div>
                  <span className="font-medium">{pt.text}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

const INTERACTIVE_SERVICES = [
  { 
    id: "transportation",
    icon: Truck, 
    title: "Transportation", 
    shortDesc: "Versatile fleet for workforce mobility",
    description: "We offer a versatile fleet of buses, coasters, Hiace vans, pickups, and cars designed to facilitate workforce mobility for projects of all sizes. Our transportation services incorporate advanced GPS tracking, route optimization, and fully compliant operations, ensuring the highest standards of safety, efficiency, and reliability.",
    image: "https://images.unsplash.com/photo-1610491461947-f050c33a970e?q=80&w=1000&auto=format&fit=crop", // Fleet/Logistics
    details: [
      "Buses, coasters, and Hiace vans",
      "Pickups and cars",
      "Advanced GPS tracking",
      "Route optimization"
    ]
  },
  { 
    id: "equipment",
    icon: Wrench, 
    title: "Equipment", 
    shortDesc: "Comprehensive equipment & tools",
    description: "Comprehensive selection of construction equipment tailored to project specifications, including telemetry, preventive maintenance, and dedicated service support. Our inventory features heavy machinery, generators, and specialized tools to meet diverse operational requirements.",
    image: "https://images.unsplash.com/photo-1589939705384-5185137a7f0f?q=80&w=1000&auto=format&fit=crop", // Excavator/Machinery
    details: [
      "Heavy machinery operations",
      "Power generation equipment",
      "Specialized industrial tools",
      "Preventive maintenance"
    ]
  },
  { 
    id: "manpower",
    icon: Users, 
    title: "Manpower", 
    shortDesc: "Skilled workforce supply",
    description: "Delivering skilled and unskilled workforce solutions tailored to client needs, ensuring efficiency and productivity on every project. We connect businesses with professionals who drive success and foster growth.",
    image: "https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?q=80&w=1000&auto=format&fit=crop", // Team of engineers/workers
    details: [
      "Civil, Mechanical, and Electrical Engineers",
      "Skilled technicians and supervisors",
      "Safety managers and officers",
      "Thousands of ready-to-deploy manpower"
    ]
  },
  { 
    id: "construction",
    icon: Building, 
    title: "Construction", 
    shortDesc: "Civil, electrical & mechanical",
    description: "We have successfully executed a diverse portfolio of engineering projects across multiple sectors. Our company has extensive experience in delivering large-scale and small-scale civil, electrical, mechanical, and steel structure projects safely and efficiently.",
    image: "https://images.unsplash.com/photo-1541888086425-d81bb19240f5?q=80&w=1000&auto=format&fit=crop", // Industrial construction site
    details: [
      "Large and small-scale civil projects",
      "Electrical installation and compliance",
      "Mechanical works and commissioning",
      "Steel structure fabrication and erection"
    ]
  },
  { 
    id: "realestate",
    icon: MapPin, 
    title: "Real Estate Rentals", 
    shortDesc: "Camps, villas, and warehouses",
    description: "We provide rental solutions including hotel rooms, villas, apartments, camps for junior and senior staff, and warehouses on a short-term and long-term basis. Our diverse portfolio enables us to deliver reliable and cost-effective solutions to our clients.",
    image: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?q=80&w=1000&auto=format&fit=crop", // Modern villas/buildings
    details: [
      "Hotel rooms, villas, and apartments",
      "Camps for junior and senior staff",
      "Short-term and long-term basis",
      "Cost-effective and reliable solutions"
    ]
  },
  { 
    id: "catering",
    icon: Utensils, 
    title: "Catering", 
    shortDesc: "Professional food services",
    description: "We offer professional catering services for weddings, ceremonies, events, functions, and parties. Our catering services include menu planning, food preparation, and on-site service, tailored to each client's specific needs with a commitment to quality.",
    image: "https://images.unsplash.com/photo-1555244162-803834f70033?q=80&w=1000&auto=format&fit=crop",
    details: [
      "Catering for corporate and industrial settings",
      "Events, weddings, and ceremonies",
      "Menu planning and on-site service",
      "Commitment to quality and hygiene"
    ]
  },
  { 
    id: "events",
    icon: CalendarDays, 
    title: "Events", 
    shortDesc: "Planning and execution",
    description: "We specialize in organizing and managing ceremonies, weddings, events, functions, and parties, delivering seamless and memorable experiences. Our team has proven expertise in end-to-end event planning and execution.",
    image: "https://images.unsplash.com/photo-1511556532299-8f662fc26c06?q=80&w=1000&auto=format&fit=crop",
    details: [
      "End-to-end event planning",
      "Ceremonies and corporate events",
      "Functions and private parties",
      "On-site coordination and management"
    ]
  }
];

function InteractiveServices() {
  const [activeId, setActiveId] = useState(INTERACTIVE_SERVICES[0].id);
  const activeService = INTERACTIVE_SERVICES.find(s => s.id === activeId) || INTERACTIVE_SERVICES[0];

  return (
    <section id="services" className="py-24 bg-industrial-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-display text-4xl font-bold tracking-tight text-industrial-900 mb-4">Our Services</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Comprehensive solutions for every industry. Select a service below to learn more.</p>
          <div className="w-16 h-1 bg-accent mx-auto mt-6"></div>
        </div>

        <div className="flex flex-col lg:flex-row gap-8 lg:gap-12">
          {/* Service List */}
          <div className="w-full lg:w-1/3 space-y-2">
            {INTERACTIVE_SERVICES.map((srv) => {
              const isActive = srv.id === activeId;
              return (
                <button
                  key={srv.id}
                  onClick={() => setActiveId(srv.id)}
                  className={`w-full flex items-center justify-between p-5 text-left transition-all duration-300 ${isActive ? 'bg-industrial-900 text-white shadow-md' : 'bg-white text-gray-700 hover:bg-gray-50'}`}
                >
                  <div className="flex items-center gap-4">
                    <srv.icon className={`w-6 h-6 ${isActive ? 'text-accent' : 'text-gray-400'}`} />
                    <div>
                      <span className="block font-display font-semibold text-lg">{srv.title}</span>
                      <span className={`block text-sm ${isActive ? 'text-gray-300' : 'text-gray-500'}`}>{srv.shortDesc}</span>
                    </div>
                  </div>
                  <ChevronDown className={`w-5 h-5 transition-transform duration-300 ${isActive ? '-rotate-90 text-accent' : '-rotate-90 opacity-0'}`} />
                </button>
              );
            })}
          </div>

          {/* Service Details View */}
          <div className="w-full lg:w-2/3 h-[500px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeService.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="bg-white h-full flex flex-col items-center justify-start shadow-sm"
              >
                <div className="w-full h-64 md:h-[280px] relative">
                  <img src={activeService.image} alt={activeService.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-gradient-to-t from-industrial-900/80 to-transparent"></div>
                  <div className="absolute bottom-6 left-8 flex items-center gap-4">
                    <div className="w-12 h-12 bg-accent rounded flex items-center justify-center text-white">
                      <activeService.icon className="w-6 h-6" />
                    </div>
                    <h3 className="font-display text-3xl font-bold text-white">{activeService.title}</h3>
                  </div>
                </div>
                
                <div className="p-8 w-full flex-grow flex flex-col justify-between overflow-y-auto">
                  <div>
                    <h4 className="text-xs font-semibold text-gray-500 mb-2 uppercase tracking-wider">Overview</h4>
                    <p className="text-gray-700 font-light mb-6 text-sm">{activeService.description}</p>
                    
                    <h4 className="text-xs font-semibold text-gray-500 mb-3 uppercase tracking-wider">Service Capabilities</h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-6">
                      {activeService.details.map((detail, idx) => (
                        <div key={idx} className="flex items-start gap-2 text-gray-800 text-sm">
                          <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
                          <span>{detail}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="mt-6 pt-6 border-t border-gray-100 shrink-0">
                    <a href="#contact" className="inline-flex items-center gap-2 text-industrial-900 font-bold hover:text-accent transition-colors uppercase tracking-wide text-sm">
                      Request this service <ArrowRight className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}

const CLIENTS = [
  "Saudi Aramco", "SABIC", "Emaar", "Initial", "Hill International", "SWVL"
];

function ClientsSection() {
  return (
    <section className="py-24 bg-industrial-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center border-t border-gray-200 pt-16 mt-[-4rem]">
        <h2 className="font-display text-2xl font-bold text-industrial-900 mb-2">Trusted by Leading Companies</h2>
        <p className="text-gray-500 mb-12">We support major industrial and construction projects</p>
        
        <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
          {CLIENTS.map((client, idx) => (
            <div key={idx} className="font-display font-bold text-xl md:text-2xl text-industrial-800 uppercase tracking-widest">
              {client}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ContactSection() {
  return (
    <section id="contact" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Form */}
          <div>
            <h2 className="font-display text-4xl font-bold tracking-tight text-industrial-900 mb-4">
              Start Your Project Today
            </h2>
            <p className="text-gray-600 mb-8 text-lg">Talk to our team and get a custom solution.</p>
            
            <form className="space-y-6" onSubmit={(e) => { e.preventDefault(); alert('For this demo, form submissions are disabled. In production, connect this to EmailJS or a backend.'); }}>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Name</label>
                  <input type="text" className="w-full p-4 border-b border-gray-300 focus:border-accent focus:outline-none transition-colors" placeholder="John Doe" />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Email</label>
                  <input type="email" className="w-full p-4 border-b border-gray-300 focus:border-accent focus:outline-none transition-colors" placeholder="john@company.com" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Phone</label>
                <input type="tel" className="w-full p-4 border-b border-gray-300 focus:border-accent focus:outline-none transition-colors" placeholder="+966 5X XXX XXXX" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Message</label>
                <textarea rows={4} className="w-full p-4 border-b border-gray-300 focus:border-accent focus:outline-none transition-colors resize-none" placeholder="Tell us about your requirements..."></textarea>
              </div>
              <button className="bg-industrial-900 text-white font-bold uppercase tracking-widest text-sm px-8 py-4 hover:bg-accent transition-colors w-full sm:w-auto">
                Send Request
              </button>
            </form>
          </div>
          
          {/* Contact Info */}
          <div className="bg-industrial-100 p-8 md:p-12 h-full flex flex-col justify-center">
            <h3 className="font-display text-2xl font-bold mb-8">Contact Information</h3>
            <div className="space-y-8">
              <div className="flex items-start gap-4">
                <Phone className="w-6 h-6 text-accent mt-1" />
                <div>
                  <p className="font-semibold text-industrial-900 leading-none mb-1">Phone</p>
                  <p className="text-gray-600">0541451894</p>
                  <p className="text-gray-600">0597502683</p>
                  <p className="text-gray-600">0548658274</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Mail className="w-6 h-6 text-accent mt-1" />
                <div>
                  <p className="font-semibold text-industrial-900 leading-none mb-1">Email</p>
                  <p className="text-gray-600">sawaedalnafah@outlook.com</p>
                  <p className="text-gray-600">irfank1437@gmail.com</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <MapPin className="w-6 h-6 text-accent mt-1" />
                <div>
                  <p className="font-semibold text-industrial-900 leading-none mb-1">Location</p>
                  <p className="text-gray-600">Office No 223 Emaar Building,</p>
                  <p className="text-gray-600">King Abdullah Economic City.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="bg-industrial-900 text-white py-16 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-12">
        <div className="col-span-1 md:col-span-1">
          <div className="flex items-center mb-6">
            <img src="/logo.png" alt="Sawaed Company Logo" className="h-16 w-auto object-contain bg-white rounded p-1" />
          </div>
          <p className="text-gray-400 text-sm font-light">
            Reliable solutions for every project.
          </p>
        </div>
        
        <div>
          <h4 className="font-display font-semibold mb-6 uppercase tracking-wider text-sm">Company</h4>
          <ul className="space-y-3 text-sm text-gray-400">
            <li><a href="#" className="hover:text-accent transition-colors">Home</a></li>
            <li><a href="#about" className="hover:text-accent transition-colors">About</a></li>
            <li><a href="#services" className="hover:text-accent transition-colors">Services</a></li>
            <li><a href="#contact" className="hover:text-accent transition-colors">Contact</a></li>
          </ul>
        </div>
        
        <div>
          <h4 className="font-display font-semibold mb-6 uppercase tracking-wider text-sm">Services</h4>
          <ul className="space-y-3 text-sm text-gray-400">
            <li>Transportation</li>
            <li>Equipment Rental</li>
            <li>Manpower Supply</li>
            <li>Real Estate Rentals</li>
            <li>Construction Services</li>
          </ul>
        </div>
        
        <div>
          <h4 className="font-display font-semibold mb-6 uppercase tracking-wider text-sm">Connect</h4>
          <ul className="space-y-3 text-sm text-gray-400">
            <li>0541451894</li>
            <li>sawaedalnafah@outlook.com</li>
            <li>Office 223, Emaar Bldg, KAEC</li>
          </ul>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-16 pt-8 border-t border-white/10 text-center text-sm text-gray-500 flex flex-col sm:flex-row justify-between items-center gap-4">
        <p>&copy; 2026 Sawaed Al Nafah. All rights reserved.</p>
        <p>Built for Industrial Excellence.</p>
      </div>
    </footer>
  );
}

